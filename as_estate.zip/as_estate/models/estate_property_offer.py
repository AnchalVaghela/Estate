from odoo import models,fields

class as_estate_offer(models.Model):
    _name = 'as.estate.offer.model'
    _description = 'Estate Offer Model'


    test_ids = fields.One2many("as_estate_model", "partner_id", string="Tests")
    price = fields.Float()
    status = fields.Selection([
        ('accepted','Accepted'),
        ('refused','Refused'),
    ],copy=False)
    partner_id = fields.Many2one("res.partner",required = True)
    property_id = fields.Many2one("as.estate.model",required=True)


    # for test in partner.test_ids:
    #     print(test.name)

