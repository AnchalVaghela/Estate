# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import timedelta

class as_estate(models.Model):
    _name = 'as.estate.model'
    _description = 'Estate Model'

    property_type = fields.Many2one("as.estate.type.model",string="PropertyType")
    buyer = fields.Many2one("res.partner",string="Buyer")
    seller = fields.Many2one("res.users",string="Seller",default=lambda self: self.env.user)

    tag_id = fields.Many2many("as.estate.tag.model",string="tag")
    offer_ids = fields.One2many("estate.property.offer", "property_id", string="Offers")

    # user_id = fields.Many2one('res.users', string='Salesperson', index=True, tracking=True, default=lambda self: self.env.user)
    
    name = fields.Char(string='Title',default="Unknown")
    # last_seen = fields.Datetime("Last Seen", default=fields.Datetime.now)
    description = fields.Text()
    postcode = fields.Char()
    # date_availability = fields.Datetime(copy=False,default=fields.Date + )
    date_availability = fields.Datetime(string='Available Date', copy=False, default=lambda self: fields.Datetime.today() + timedelta(days=90))  

    expected_price = fields.Float(required=True)
    selling_price = fields.Float(readonly=True,copy=False)
    bedrooms = fields.Integer(default=2)
    living_area = fields.Integer()
    facades = fields.Integer()
    
    garage = fields.Boolean()
    garden = fields.Boolean()
    garden_area = fields.Integer()
    garden_orientation = fields.Selection(string="Type",selection=[('north','North'),('south','South'),('east','East'),('west','West')])
    # active = fields.Boolean(default=True)
    state = fields.Selection(selection=[("new","New"), ("offerReceived","OfferReceived",) ,("offerAccepted","OfferAccepted"), ("Sold","Sold"), ("cancelled" ,"Cancelled" )],default="new")
