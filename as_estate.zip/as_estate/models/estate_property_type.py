

from odoo import models,fields

class as_estate_type(models.Model):
    _name = 'as.estate.type.model'
    _description = "Estate Type Model"

    name = fields.Char(required=True)