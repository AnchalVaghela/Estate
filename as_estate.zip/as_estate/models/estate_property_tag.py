from odoo import models,fields

class as_estate_tag(models.Model):
    _name = 'as.estate.tag.model'
    _description = "Estate Tag Model"

    name = fields.Char(required=True)